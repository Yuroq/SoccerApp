import React,{useState} from "react";
import classes from "./Application.module.css";

export const Context = React.createContext()

function LeaguesNavBar() {
const [league, setLeague] = useState('')

return    <div className={classes.nav}>
      
  </div>
}

export default LeaguesNavBar;